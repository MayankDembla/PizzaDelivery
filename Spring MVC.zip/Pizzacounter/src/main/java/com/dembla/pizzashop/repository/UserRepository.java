package com.dembla.pizzashop.repository;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.dembla.pizzashop.domain.User;

@Service
@Component
public interface UserRepository extends GenericDao<User, Long> {

	User getUserByUsername(String username) ; 
	
}
