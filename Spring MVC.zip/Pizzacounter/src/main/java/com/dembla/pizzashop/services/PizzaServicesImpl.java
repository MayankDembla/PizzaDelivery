package com.dembla.pizzashop.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.dembla.pizzashop.domain.BasePizza;
import com.dembla.pizzashop.repository.PizzaRepository;


@Repository
@Component
public class PizzaServicesImpl implements PizzaServices {

	@Autowired
	private PizzaRepository pizzaRepository;
	
	@Override
	public void orderPizza(String pizzaName, String type) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addPizza(BasePizza basepizza) {
		pizzaRepository.add(basepizza);
	}

	@Override
	public void deletePizza(BasePizza basepizza) {
		pizzaRepository.remove(basepizza);
	}

	@Override
	public void modifyPizza(BasePizza basepizza) {
		pizzaRepository.update(basepizza);
	}

	@Override
	public List<BasePizza> getallPizza() {
		 
		return  pizzaRepository.list() ; 
	}
}
