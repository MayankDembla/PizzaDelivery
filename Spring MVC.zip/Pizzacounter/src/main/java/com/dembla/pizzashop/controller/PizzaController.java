package com.dembla.pizzashop.controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dembla.pizzashop.domain.BasePizza;
import com.dembla.pizzashop.domain.BaseTopping;
import com.dembla.pizzashop.domain.Pizza;
import com.dembla.pizzashop.domain.User;
import com.dembla.pizzashop.services.PizzaServices;
import com.dembla.pizzashop.services.ToppingServices;
import com.dembla.pizzashop.services.UserServices;

@Controller
@RequestMapping(value = "/pizza")
public class PizzaController {
	
	@Autowired
	private UserServices uService;	
	
	@Autowired
	private PizzaServices pService ; 
	
	@Autowired
	private ToppingServices tService ; 
	
	@RequestMapping("/home")
	public String getHomePage(Model model ) { 
		return "home" ; 
 	}
	
	@RequestMapping("/login")
	public String getloginPage(Model model ) { 
		model.addAttribute("login", new User());
		return "login" ; 
 	}
	
	@RequestMapping("/register")
	public String getregisterPage(Model model ) { 
		model.addAttribute("register", new User());
		return "register" ; 
 	}
	
	@RequestMapping("/validateuser")
	public ModelAndView loginServlet(@ModelAttribute("user") User user,HttpSession session) {
	
		int res = uService.login(user);
		
		if(res == 3)  // User Not Exist 
		{
			ModelAndView mv = new ModelAndView("login");
			mv.addObject("res", 2);
			return mv;
		}
		else  // User Exist  
		{
			ModelAndView mv = new ModelAndView("welcome");
			mv.addObject("user", user);
			mv.addObject("type", res);
			session.setAttribute("user", user);
			session.setAttribute("type", res);
			return mv;
		}
		
	}
	
	@RequestMapping("/registeruser")
	public ModelAndView RegisterServlet(Model model, @Valid @ModelAttribute("register") User users, BindingResult br,
			Errors er) {

		if (br.hasErrors()) {
			System.out.println("Error Occured !!" + br.getErrorCount());
			return new ModelAndView("register");
		} else {
			
			System.out.println("No Error !!");

			if (uService.registerUser(users)) {
				ModelAndView mv = new ModelAndView("login");
				mv.addObject("res", 0);
				return mv;
			} else {
				ModelAndView mv = new ModelAndView("register");
				mv.addObject("res", 1);
				return mv;
			}

		}
	}
	
	// ################# Pizza CRUD ################################# // 
	
	
	@RequestMapping("pizzaadmin")
	public String getpizzamodification(Model model) {
		return "pizzaadmin" ; 
	}
	
	@RequestMapping("addpizza")
	public String addPizza(Model model) {
		model.addAttribute("basepizza",new BasePizza()) ; 
		return "addpizza" ; 
	}
	
	@RequestMapping("addpizzadb")
	public String addPizzadb(Model model,@ModelAttribute("basepizza") BasePizza basepizza) {
		pService.addPizza(basepizza);
		model.addAttribute("res", 3);
		return "pizzaadmin" ; 
	}
	
	// ############### Topping CRUD ########### // 
	
	
	@RequestMapping("toppingadmin")
	public String gettoppingview(Model model) {
		return "toppingadmin" ; 
	}
	
	@RequestMapping("addtopping")
	public String addTopping(Model model) {
		model.addAttribute("basepizza",new BaseTopping()) ; 
		return "addtopping" ; 
	}
	
	@RequestMapping("/addtoppingdb")
	public String addToppingdb(Model model,@ModelAttribute("basetopping") BaseTopping basetopping) {
		tService.addTopping(basetopping);
		model.addAttribute("res", 4);
		return "toppingadmin" ; 
	}
	
	// ################# Log Out ############## //
	
	@RequestMapping("/logout")
	public ModelAndView logoutServlet(HttpSession session) {
		ModelAndView mv = new ModelAndView("home");
			session.setAttribute("user", null);
			session.setAttribute("type", null);
			return mv;
	}
	
	// ################### Order Crud ################### //
	
	@GetMapping("/showmenu")
	public String showMenu(Model model) { 
	 	List<BasePizza> allpizza = pService.getallPizza() ; 
	    List<BaseTopping> allToppings = 	tService.showallToppings() ; 
	 
		model.addAttribute("pizza",allpizza) ;
		model.addAttribute("topping", allToppings); 
		return "menu";
	}
	
	@GetMapping("/orderPizza")
	public String orderPizza(Model model) { 
	  
		return "showmenu" ; 
	}
	
	
	
}
