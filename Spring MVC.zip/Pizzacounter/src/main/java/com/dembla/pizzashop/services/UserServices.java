package com.dembla.pizzashop.services;

import org.springframework.stereotype.Service;

import com.dembla.pizzashop.domain.User;

@Service("UserServices")
public interface UserServices {

	 boolean registerUser(User u);

	 int login(User u);
}
