package com.dembla.pizzashop.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.dembla.pizzashop.domain.BasePizza;

@Service("PizzaService")
public interface PizzaServices {
	
	/**
	 * this is to commit order for a particular customer  
	 */
	void orderPizza(String pizzaName , String type) ;
	
    void addPizza(BasePizza basePizza) ; 
    
    void deletePizza(BasePizza basepizza) ; 
    
    void modifyPizza(BasePizza basepizza) ;
    
    List<BasePizza> getallPizza() ; 

}
