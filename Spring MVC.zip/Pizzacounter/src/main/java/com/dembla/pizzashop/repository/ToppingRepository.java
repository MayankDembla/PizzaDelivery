package com.dembla.pizzashop.repository;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.dembla.pizzashop.domain.BaseTopping;

@Service
@Component
public interface ToppingRepository extends GenericDao<BaseTopping, Long> {
	
	// CRUD Already Inherited

}
