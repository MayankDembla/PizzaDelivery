package com.dembla.pizzashop.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.dembla.pizzashop.domain.BaseTopping;
import com.dembla.pizzashop.repository.ToppingRepository;


@Repository
@Component
public class ToppingServicesImpl implements ToppingServices {

	@Autowired
	private ToppingRepository trepository ; 
	
	
	@Override
	public void addTopping(BaseTopping basetopping) {
		trepository.add(basetopping);
	}

	@Override
	public void deleteTopping(BaseTopping basetopping) {
		trepository.remove(basetopping);
	}

	@Override
	public void modifyTopping(BaseTopping basetopping) {
		trepository.update(basetopping);
		
	}

	@Override
	public List<BaseTopping> showallToppings() {
		return trepository.list() ; 
	}
	
}
