package com.dembla.pizzashop.domain;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Component;

@Entity
@Component
public class BasePizza {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long baseid;

	@NotNull(message = "Field can not be empty")
	private String pizzaName;

	@NotNull(message = "Field can not be empty")
	private int small;

	@NotNull(message = "Field can not be empty")
	private int medium;

	@NotNull(message = "Field can not be empty")
	private int large;

	@OneToMany(mappedBy = "base")
	private List<Pizza> pizza;

	public Long getId() {
		return baseid;
	}

	public void setId(Long baseid) {
		this.baseid = baseid;
	}

	public String getPizzaName() {
		return pizzaName;
	}

	public void setPizzaName(String pizzaName) {
		this.pizzaName = pizzaName;
	}

	public int getSmall() {
		return small;
	}

	public void setSmall(int small) {
		this.small = small;
	}

	public int getMedium() {
		return medium;
	}

	public void setMedium(int medium) {
		this.medium = medium;
	}

	public int getLarge() {
		return large;
	}

	public void setLarge(int large) {
		this.large = large;
	}

	public int getCost(String name) {

		switch (name) {
		case "small":
			return this.small;
		case "medium":
			return this.medium;
		case "large":
			return this.large;
		}

		return 0;
	}

	public Long getBaseid() {
		return baseid;
	}

	public void setBaseid(Long baseid) {
		this.baseid = baseid;
	}

	public List<Pizza> getPizza() {
		return pizza;
	}

	public void setPizza(List<Pizza> pizza) {
		this.pizza = pizza;
	}

//	@Override
//	public String toString() {
//		return "BasePizza [baseid=" + baseid + ", pizzaName=" + pizzaName + ", small=" + small + ", medium=" + medium
//				+ ", large=" + large + ", pizza=" + pizza + "]";
//	}
	
	
}
