package com.dembla.pizzashop.repository;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.dembla.pizzashop.domain.User;

@Repository
public class UserRepositoryImpl extends HibernateDao<User, Long> implements UserRepository {

	// Generic methods Inherited automatically

	@Override
	public User getUserByUsername(String username) {

		Criteria criteria = currentSession().createCriteria(User.class);
		criteria.add(Restrictions.eq("username", username));
		
		List<User> user = criteria.list(); 
		
		if(user.isEmpty())
			return null ;  
		
		
		return (User) criteria.list().get(0);

	}

}
