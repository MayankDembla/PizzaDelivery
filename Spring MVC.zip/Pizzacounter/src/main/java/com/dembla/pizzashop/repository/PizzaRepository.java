package com.dembla.pizzashop.repository;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.dembla.pizzashop.domain.BasePizza;
import com.dembla.pizzashop.domain.BaseTopping;

@Service
@Component
public interface PizzaRepository extends GenericDao<BasePizza, Long> {
	
	BasePizza getPizza(String pizzaName , String size) ; 
	
	BaseTopping getTopping(String toppingName ) ; 

}
