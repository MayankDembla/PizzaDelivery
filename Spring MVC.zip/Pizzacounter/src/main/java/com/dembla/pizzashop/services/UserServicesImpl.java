package com.dembla.pizzashop.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import com.dembla.pizzashop.domain.User;
import com.dembla.pizzashop.repository.UserRepository;

@Repository
@Component
public class UserServicesImpl implements UserServices {

	@Autowired
	private UserRepository userrepo;

	@Override
	public boolean registerUser(User u) {

		if (userrepo.getUserByUsername(u.getUsername()) == null) {
			userrepo.add(u);
			return true;
		}

		return false;
	}

	/**
	 * return 1 - user exist 2 - if Not Exist
	 * 
	 */
	@Override
	public int login(User u) {

		if (userrepo.getUserByUsername(u.getUsername()) == null)
			return 3;

		User user = userrepo.getUserByUsername(u.getUsername()); // as it is unique

		if (user.getPassword().equals(u.getPassword()) && user.getUsername().equals(u.getUsername()))
			return user.getRole();

		return 3;
	}

}
