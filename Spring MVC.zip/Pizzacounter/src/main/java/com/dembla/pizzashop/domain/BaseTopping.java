package com.dembla.pizzashop.domain;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import org.springframework.stereotype.Component;

@Entity
@Component
public class BaseTopping {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long toppingId ; 
	
	@Column(unique = true)
	private String toppingname ; 
	
	private int cost ;
	
	@ManyToMany(mappedBy = "topping")
	private List<Pizza> pizza ; 

	public long getToppingId() {
		return toppingId;
	}

	public void setToppingId(long toppingId) {
		this.toppingId = toppingId;
	}

	public String getToppingname() {
		return toppingname;
	}

	public void setToppingname(String toppingname) {
		this.toppingname = toppingname;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public List<Pizza> getPizza() {
		return pizza;
	}

	public void setPizza(List<Pizza> pizza) {
		this.pizza = pizza;
	}
	
	
}
