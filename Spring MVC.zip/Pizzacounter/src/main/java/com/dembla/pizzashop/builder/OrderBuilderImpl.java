package com.dembla.pizzashop.builder;

import com.dembla.pizzashop.domain.Pizza;

public class OrderBuilderImpl extends OrderBuilder {
	
	@Override
	public void add(Pizza pizza) {
	   
		// Add Pizza to Order
		order.getPizza().add(pizza) ;
		
		// Update the Order Cost
		order.setorderCost(order.getorderCost() + pizza.getCost());
		
	}
	
}
