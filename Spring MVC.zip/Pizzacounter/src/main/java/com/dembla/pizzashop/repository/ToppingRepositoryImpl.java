package com.dembla.pizzashop.repository;

import org.springframework.stereotype.Repository;

import com.dembla.pizzashop.domain.BaseTopping;

@Repository
public class ToppingRepositoryImpl extends HibernateDao<BaseTopping, Long> implements ToppingRepository {
	
	// Can Add more Methods TODO

}
