package com.dembla.pizzashop.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.dembla.pizzashop.domain.BaseTopping;

@Service("ToppingService")
public interface ToppingServices {
	
    void addTopping(BaseTopping basetopping) ; 
    
    void deleteTopping(BaseTopping basetopping) ; 
    
    void modifyTopping(BaseTopping basetopping) ; 

    List<BaseTopping> showallToppings() ;
}
