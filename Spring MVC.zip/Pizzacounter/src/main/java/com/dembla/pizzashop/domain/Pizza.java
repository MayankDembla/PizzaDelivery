package com.dembla.pizzashop.domain;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import org.springframework.stereotype.Component;

@Entity
@Component
public class Pizza {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int pizzaId;

	private String type;

	private int finalCost;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "Pizza_Topping", joinColumns = @JoinColumn(referencedColumnName = "pizzaId"), inverseJoinColumns = {
			@JoinColumn(referencedColumnName = "toppingId") })
	private List<BaseTopping> topping;

	@ManyToOne
	private BasePizza base;
	
	@ManyToOne
	private Order order;

	public int getPizzaId() {
		return pizzaId;
	}

	public void setPizzaId(int pizzaId) {
		this.pizzaId = pizzaId;
	}

	public BasePizza getBase() {
		return base;
	}

	public void setBase(BasePizza base) {
		this.base = base;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getCost() {
		return finalCost;
	}

	public void setCost(int finalCost) {
		this.finalCost = finalCost;
	}

	public List<BaseTopping> getTopping() {
		return topping;
	}

	public void setTopping(List<BaseTopping> topping) {
		this.topping = topping;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}
	
	
	
}
